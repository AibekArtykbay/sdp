package com.company;

public class BowAndArrowBehavior implements WeaponBehavior{
    @Override
    public void useWeapon() {
        System.out.println("I use a Bow and Arrow");
    }
}
